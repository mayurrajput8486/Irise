// function handleClick(){
//     $("#deshbord_page").addClass("hidden");
//     $("#patients_page").removeClass("hidden");
// }
function dashClick(event) {
    event.preventDefault();

    $("#deshbord_page").removeClass("hidden");
    $("#patients_page").addClass("hidden");
    $("#Appointments_page").addClass("hidden");
    $("#Schedule_page").addClass("hidden");

    //menu active
    $("#dashboardactive").addClass("active");
    $("#Patientsactive").removeClass("active");
    $("#Appointmentsactive").removeClass("active");
    $("#Scheduleactive").removeClass("active");
    
}
function Patientstab(event) {
    event.preventDefault();

    $("#deshbord_page").addClass("hidden");
    $("#patients_page").removeClass("hidden");
    $("#Appointments_page").addClass("hidden");
    $("#Schedule_page").addClass("hidden");

     //menu active
     $("#dashboardactive").removeClass("active");
     $("#Patientsactive").addClass("active");
     $("#Appointmentsactive").removeClass("active");
     $("#Scheduleactive").removeClass("active");
}

function appointmentstime(event) {
    event.preventDefault();

    $("#deshbord_page").addClass("hidden");
    $("#patients_page").addClass("hidden");
    $("#Appointments_page").removeClass("hidden");
    $("#Schedule_page").addClass("hidden");

     //menu active
     $("#dashboardactive").removeClass("active");
     $("#Patientsactive").removeClass("active");
     $("#Appointmentsactive").addClass("active");
     $("#Scheduleactive").removeClass("active");
     
     
}

function schedules(event) {
    event.preventDefault();

    $("#deshbord_page").addClass("hidden");
    $("#patients_page").addClass("hidden");
    $("#Appointments_page").addClass("hidden");
    $("#Schedule_page").removeClass("hidden");

     //menu active
     $("#dashboardactive").removeClass("active");
     $("#Patientsactive").removeClass("active");
     $("#Appointmentsactive").removeClass("active");
     $("#Scheduleactive").addClass("active");
}
